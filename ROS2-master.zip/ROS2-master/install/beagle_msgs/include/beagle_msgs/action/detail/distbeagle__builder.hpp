// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from beagle_msgs:action/Distbeagle.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__ACTION__DETAIL__DISTBEAGLE__BUILDER_HPP_
#define BEAGLE_MSGS__ACTION__DETAIL__DISTBEAGLE__BUILDER_HPP_

#include "beagle_msgs/action/detail/distbeagle__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace beagle_msgs
{

namespace action
{

namespace builder
{

class Init_Distbeagle_Goal_target_distance
{
public:
  Init_Distbeagle_Goal_target_distance()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::beagle_msgs::action::Distbeagle_Goal target_distance(::beagle_msgs::action::Distbeagle_Goal::_target_distance_type arg)
  {
    msg_.target_distance = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::action::Distbeagle_Goal>()
{
  return beagle_msgs::action::builder::Init_Distbeagle_Goal_target_distance();
}

}  // namespace beagle_msgs


namespace beagle_msgs
{

namespace action
{

namespace builder
{

class Init_Distbeagle_Result_current_distance
{
public:
  Init_Distbeagle_Result_current_distance()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::beagle_msgs::action::Distbeagle_Result current_distance(::beagle_msgs::action::Distbeagle_Result::_current_distance_type arg)
  {
    msg_.current_distance = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::action::Distbeagle_Result>()
{
  return beagle_msgs::action::builder::Init_Distbeagle_Result_current_distance();
}

}  // namespace beagle_msgs


namespace beagle_msgs
{

namespace action
{

namespace builder
{

class Init_Distbeagle_Feedback_success
{
public:
  Init_Distbeagle_Feedback_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::beagle_msgs::action::Distbeagle_Feedback success(::beagle_msgs::action::Distbeagle_Feedback::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::action::Distbeagle_Feedback>()
{
  return beagle_msgs::action::builder::Init_Distbeagle_Feedback_success();
}

}  // namespace beagle_msgs


namespace beagle_msgs
{

namespace action
{

namespace builder
{

class Init_Distbeagle_SendGoal_Request_goal
{
public:
  explicit Init_Distbeagle_SendGoal_Request_goal(::beagle_msgs::action::Distbeagle_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::beagle_msgs::action::Distbeagle_SendGoal_Request goal(::beagle_msgs::action::Distbeagle_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_SendGoal_Request msg_;
};

class Init_Distbeagle_SendGoal_Request_goal_id
{
public:
  Init_Distbeagle_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Distbeagle_SendGoal_Request_goal goal_id(::beagle_msgs::action::Distbeagle_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_Distbeagle_SendGoal_Request_goal(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::action::Distbeagle_SendGoal_Request>()
{
  return beagle_msgs::action::builder::Init_Distbeagle_SendGoal_Request_goal_id();
}

}  // namespace beagle_msgs


namespace beagle_msgs
{

namespace action
{

namespace builder
{

class Init_Distbeagle_SendGoal_Response_stamp
{
public:
  explicit Init_Distbeagle_SendGoal_Response_stamp(::beagle_msgs::action::Distbeagle_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::beagle_msgs::action::Distbeagle_SendGoal_Response stamp(::beagle_msgs::action::Distbeagle_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_SendGoal_Response msg_;
};

class Init_Distbeagle_SendGoal_Response_accepted
{
public:
  Init_Distbeagle_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Distbeagle_SendGoal_Response_stamp accepted(::beagle_msgs::action::Distbeagle_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_Distbeagle_SendGoal_Response_stamp(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::action::Distbeagle_SendGoal_Response>()
{
  return beagle_msgs::action::builder::Init_Distbeagle_SendGoal_Response_accepted();
}

}  // namespace beagle_msgs


namespace beagle_msgs
{

namespace action
{

namespace builder
{

class Init_Distbeagle_GetResult_Request_goal_id
{
public:
  Init_Distbeagle_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::beagle_msgs::action::Distbeagle_GetResult_Request goal_id(::beagle_msgs::action::Distbeagle_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::action::Distbeagle_GetResult_Request>()
{
  return beagle_msgs::action::builder::Init_Distbeagle_GetResult_Request_goal_id();
}

}  // namespace beagle_msgs


namespace beagle_msgs
{

namespace action
{

namespace builder
{

class Init_Distbeagle_GetResult_Response_result
{
public:
  explicit Init_Distbeagle_GetResult_Response_result(::beagle_msgs::action::Distbeagle_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::beagle_msgs::action::Distbeagle_GetResult_Response result(::beagle_msgs::action::Distbeagle_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_GetResult_Response msg_;
};

class Init_Distbeagle_GetResult_Response_status
{
public:
  Init_Distbeagle_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Distbeagle_GetResult_Response_result status(::beagle_msgs::action::Distbeagle_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_Distbeagle_GetResult_Response_result(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::action::Distbeagle_GetResult_Response>()
{
  return beagle_msgs::action::builder::Init_Distbeagle_GetResult_Response_status();
}

}  // namespace beagle_msgs


namespace beagle_msgs
{

namespace action
{

namespace builder
{

class Init_Distbeagle_FeedbackMessage_feedback
{
public:
  explicit Init_Distbeagle_FeedbackMessage_feedback(::beagle_msgs::action::Distbeagle_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::beagle_msgs::action::Distbeagle_FeedbackMessage feedback(::beagle_msgs::action::Distbeagle_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_FeedbackMessage msg_;
};

class Init_Distbeagle_FeedbackMessage_goal_id
{
public:
  Init_Distbeagle_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Distbeagle_FeedbackMessage_feedback goal_id(::beagle_msgs::action::Distbeagle_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_Distbeagle_FeedbackMessage_feedback(msg_);
  }

private:
  ::beagle_msgs::action::Distbeagle_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::action::Distbeagle_FeedbackMessage>()
{
  return beagle_msgs::action::builder::Init_Distbeagle_FeedbackMessage_goal_id();
}

}  // namespace beagle_msgs

#endif  // BEAGLE_MSGS__ACTION__DETAIL__DISTBEAGLE__BUILDER_HPP_
