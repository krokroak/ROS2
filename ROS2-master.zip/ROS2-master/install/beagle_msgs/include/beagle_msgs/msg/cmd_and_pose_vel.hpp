// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__MSG__CMD_AND_POSE_VEL_HPP_
#define BEAGLE_MSGS__MSG__CMD_AND_POSE_VEL_HPP_

#include "beagle_msgs/msg/detail/cmd_and_pose_vel__struct.hpp"
#include "beagle_msgs/msg/detail/cmd_and_pose_vel__builder.hpp"
#include "beagle_msgs/msg/detail/cmd_and_pose_vel__traits.hpp"

#endif  // BEAGLE_MSGS__MSG__CMD_AND_POSE_VEL_HPP_
