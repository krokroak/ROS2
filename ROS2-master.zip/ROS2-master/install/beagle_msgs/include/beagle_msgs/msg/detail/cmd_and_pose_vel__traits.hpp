// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from beagle_msgs:msg/CmdAndPoseVel.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__MSG__DETAIL__CMD_AND_POSE_VEL__TRAITS_HPP_
#define BEAGLE_MSGS__MSG__DETAIL__CMD_AND_POSE_VEL__TRAITS_HPP_

#include "beagle_msgs/msg/detail/cmd_and_pose_vel__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<beagle_msgs::msg::CmdAndPoseVel>()
{
  return "beagle_msgs::msg::CmdAndPoseVel";
}

template<>
inline const char * name<beagle_msgs::msg::CmdAndPoseVel>()
{
  return "beagle_msgs/msg/CmdAndPoseVel";
}

template<>
struct has_fixed_size<beagle_msgs::msg::CmdAndPoseVel>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<beagle_msgs::msg::CmdAndPoseVel>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<beagle_msgs::msg::CmdAndPoseVel>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // BEAGLE_MSGS__MSG__DETAIL__CMD_AND_POSE_VEL__TRAITS_HPP_
