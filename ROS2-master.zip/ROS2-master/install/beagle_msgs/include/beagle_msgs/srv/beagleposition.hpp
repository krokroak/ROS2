// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__SRV__BEAGLEPOSITION_HPP_
#define BEAGLE_MSGS__SRV__BEAGLEPOSITION_HPP_

#include "beagle_msgs/srv/detail/beagleposition__struct.hpp"
#include "beagle_msgs/srv/detail/beagleposition__builder.hpp"
#include "beagle_msgs/srv/detail/beagleposition__traits.hpp"

#endif  // BEAGLE_MSGS__SRV__BEAGLEPOSITION_HPP_
