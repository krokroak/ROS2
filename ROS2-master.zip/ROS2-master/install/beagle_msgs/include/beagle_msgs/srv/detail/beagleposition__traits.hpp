// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from beagle_msgs:srv/Beagleposition.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__SRV__DETAIL__BEAGLEPOSITION__TRAITS_HPP_
#define BEAGLE_MSGS__SRV__DETAIL__BEAGLEPOSITION__TRAITS_HPP_

#include "beagle_msgs/srv/detail/beagleposition__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<beagle_msgs::srv::Beagleposition_Request>()
{
  return "beagle_msgs::srv::Beagleposition_Request";
}

template<>
inline const char * name<beagle_msgs::srv::Beagleposition_Request>()
{
  return "beagle_msgs/srv/Beagleposition_Request";
}

template<>
struct has_fixed_size<beagle_msgs::srv::Beagleposition_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<beagle_msgs::srv::Beagleposition_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<beagle_msgs::srv::Beagleposition_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<beagle_msgs::srv::Beagleposition_Response>()
{
  return "beagle_msgs::srv::Beagleposition_Response";
}

template<>
inline const char * name<beagle_msgs::srv::Beagleposition_Response>()
{
  return "beagle_msgs/srv/Beagleposition_Response";
}

template<>
struct has_fixed_size<beagle_msgs::srv::Beagleposition_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<beagle_msgs::srv::Beagleposition_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<beagle_msgs::srv::Beagleposition_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<beagle_msgs::srv::Beagleposition>()
{
  return "beagle_msgs::srv::Beagleposition";
}

template<>
inline const char * name<beagle_msgs::srv::Beagleposition>()
{
  return "beagle_msgs/srv/Beagleposition";
}

template<>
struct has_fixed_size<beagle_msgs::srv::Beagleposition>
  : std::integral_constant<
    bool,
    has_fixed_size<beagle_msgs::srv::Beagleposition_Request>::value &&
    has_fixed_size<beagle_msgs::srv::Beagleposition_Response>::value
  >
{
};

template<>
struct has_bounded_size<beagle_msgs::srv::Beagleposition>
  : std::integral_constant<
    bool,
    has_bounded_size<beagle_msgs::srv::Beagleposition_Request>::value &&
    has_bounded_size<beagle_msgs::srv::Beagleposition_Response>::value
  >
{
};

template<>
struct is_service<beagle_msgs::srv::Beagleposition>
  : std::true_type
{
};

template<>
struct is_service_request<beagle_msgs::srv::Beagleposition_Request>
  : std::true_type
{
};

template<>
struct is_service_response<beagle_msgs::srv::Beagleposition_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // BEAGLE_MSGS__SRV__DETAIL__BEAGLEPOSITION__TRAITS_HPP_
