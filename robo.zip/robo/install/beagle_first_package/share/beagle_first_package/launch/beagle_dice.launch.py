from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription(
        [
            Node(
                namespace='dice_and_point_pub',
                package='beagle_first_package',
                executable='beagle_first_pub',
                output='screen'
            ),
            Node(
                namespace='dice_and_point_sub',
                package='beagle_first_package',
                executable='beagle_first_sub',
                output='screen'
            ),
        ]
    )
