// generated from rosidl_generator_c/resource/idl.h.em
// with input from beagle_msgs:action/Distbeagle.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__ACTION__DISTBEAGLE_H_
#define BEAGLE_MSGS__ACTION__DISTBEAGLE_H_

#include "beagle_msgs/action/detail/distbeagle__struct.h"
#include "beagle_msgs/action/detail/distbeagle__functions.h"
#include "beagle_msgs/action/detail/distbeagle__type_support.h"

#endif  // BEAGLE_MSGS__ACTION__DISTBEAGLE_H_
