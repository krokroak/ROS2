// generated from rosidl_generator_c/resource/idl.h.em
// with input from beagle_msgs:msg/CmdAndPoseVel.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__MSG__CMD_AND_POSE_VEL_H_
#define BEAGLE_MSGS__MSG__CMD_AND_POSE_VEL_H_

#include "beagle_msgs/msg/detail/cmd_and_pose_vel__struct.h"
#include "beagle_msgs/msg/detail/cmd_and_pose_vel__functions.h"
#include "beagle_msgs/msg/detail/cmd_and_pose_vel__type_support.h"

#endif  // BEAGLE_MSGS__MSG__CMD_AND_POSE_VEL_H_
