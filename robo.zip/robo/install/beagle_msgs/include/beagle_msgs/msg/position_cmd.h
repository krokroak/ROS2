// generated from rosidl_generator_c/resource/idl.h.em
// with input from beagle_msgs:msg/PositionCmd.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__MSG__POSITION_CMD_H_
#define BEAGLE_MSGS__MSG__POSITION_CMD_H_

#include "beagle_msgs/msg/detail/position_cmd__struct.h"
#include "beagle_msgs/msg/detail/position_cmd__functions.h"
#include "beagle_msgs/msg/detail/position_cmd__type_support.h"

#endif  // BEAGLE_MSGS__MSG__POSITION_CMD_H_
