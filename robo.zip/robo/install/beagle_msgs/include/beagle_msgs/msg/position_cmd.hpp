// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__MSG__POSITION_CMD_HPP_
#define BEAGLE_MSGS__MSG__POSITION_CMD_HPP_

#include "beagle_msgs/msg/detail/position_cmd__struct.hpp"
#include "beagle_msgs/msg/detail/position_cmd__builder.hpp"
#include "beagle_msgs/msg/detail/position_cmd__traits.hpp"

#endif  // BEAGLE_MSGS__MSG__POSITION_CMD_HPP_
