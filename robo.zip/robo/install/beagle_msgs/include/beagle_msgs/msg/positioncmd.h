// generated from rosidl_generator_c/resource/idl.h.em
// with input from beagle_msgs:msg/Positioncmd.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__MSG__POSITIONCMD_H_
#define BEAGLE_MSGS__MSG__POSITIONCMD_H_

#include "beagle_msgs/msg/detail/positioncmd__struct.h"
#include "beagle_msgs/msg/detail/positioncmd__functions.h"
#include "beagle_msgs/msg/detail/positioncmd__type_support.h"

#endif  // BEAGLE_MSGS__MSG__POSITIONCMD_H_
