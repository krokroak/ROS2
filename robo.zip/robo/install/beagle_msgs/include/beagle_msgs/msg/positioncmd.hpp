// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__MSG__POSITIONCMD_HPP_
#define BEAGLE_MSGS__MSG__POSITIONCMD_HPP_

#include "beagle_msgs/msg/detail/positioncmd__struct.hpp"
#include "beagle_msgs/msg/detail/positioncmd__builder.hpp"
#include "beagle_msgs/msg/detail/positioncmd__traits.hpp"

#endif  // BEAGLE_MSGS__MSG__POSITIONCMD_HPP_
