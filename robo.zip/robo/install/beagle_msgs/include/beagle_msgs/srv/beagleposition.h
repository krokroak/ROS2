// generated from rosidl_generator_c/resource/idl.h.em
// with input from beagle_msgs:srv/Beagleposition.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__SRV__BEAGLEPOSITION_H_
#define BEAGLE_MSGS__SRV__BEAGLEPOSITION_H_

#include "beagle_msgs/srv/detail/beagleposition__struct.h"
#include "beagle_msgs/srv/detail/beagleposition__functions.h"
#include "beagle_msgs/srv/detail/beagleposition__type_support.h"

#endif  // BEAGLE_MSGS__SRV__BEAGLEPOSITION_H_
