// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from beagle_msgs:srv/Beagleposition.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__SRV__DETAIL__BEAGLEPOSITION__BUILDER_HPP_
#define BEAGLE_MSGS__SRV__DETAIL__BEAGLEPOSITION__BUILDER_HPP_

#include "beagle_msgs/srv/detail/beagleposition__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace beagle_msgs
{

namespace srv
{

namespace builder
{

class Init_Beagleposition_Request_user_sec
{
public:
  explicit Init_Beagleposition_Request_user_sec(::beagle_msgs::srv::Beagleposition_Request & msg)
  : msg_(msg)
  {}
  ::beagle_msgs::srv::Beagleposition_Request user_sec(::beagle_msgs::srv::Beagleposition_Request::_user_sec_type arg)
  {
    msg_.user_sec = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::srv::Beagleposition_Request msg_;
};

class Init_Beagleposition_Request_user_fir
{
public:
  Init_Beagleposition_Request_user_fir()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Beagleposition_Request_user_sec user_fir(::beagle_msgs::srv::Beagleposition_Request::_user_fir_type arg)
  {
    msg_.user_fir = std::move(arg);
    return Init_Beagleposition_Request_user_sec(msg_);
  }

private:
  ::beagle_msgs::srv::Beagleposition_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::srv::Beagleposition_Request>()
{
  return beagle_msgs::srv::builder::Init_Beagleposition_Request_user_fir();
}

}  // namespace beagle_msgs


namespace beagle_msgs
{

namespace srv
{

namespace builder
{

class Init_Beagleposition_Response_beagle_sec_position
{
public:
  explicit Init_Beagleposition_Response_beagle_sec_position(::beagle_msgs::srv::Beagleposition_Response & msg)
  : msg_(msg)
  {}
  ::beagle_msgs::srv::Beagleposition_Response beagle_sec_position(::beagle_msgs::srv::Beagleposition_Response::_beagle_sec_position_type arg)
  {
    msg_.beagle_sec_position = std::move(arg);
    return std::move(msg_);
  }

private:
  ::beagle_msgs::srv::Beagleposition_Response msg_;
};

class Init_Beagleposition_Response_beagle_fir_position
{
public:
  Init_Beagleposition_Response_beagle_fir_position()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Beagleposition_Response_beagle_sec_position beagle_fir_position(::beagle_msgs::srv::Beagleposition_Response::_beagle_fir_position_type arg)
  {
    msg_.beagle_fir_position = std::move(arg);
    return Init_Beagleposition_Response_beagle_sec_position(msg_);
  }

private:
  ::beagle_msgs::srv::Beagleposition_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::beagle_msgs::srv::Beagleposition_Response>()
{
  return beagle_msgs::srv::builder::Init_Beagleposition_Response_beagle_fir_position();
}

}  // namespace beagle_msgs

#endif  // BEAGLE_MSGS__SRV__DETAIL__BEAGLEPOSITION__BUILDER_HPP_
