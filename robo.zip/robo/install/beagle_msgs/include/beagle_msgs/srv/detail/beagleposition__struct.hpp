// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from beagle_msgs:srv/Beagleposition.idl
// generated code does not contain a copyright notice

#ifndef BEAGLE_MSGS__SRV__DETAIL__BEAGLEPOSITION__STRUCT_HPP_
#define BEAGLE_MSGS__SRV__DETAIL__BEAGLEPOSITION__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__beagle_msgs__srv__Beagleposition_Request __attribute__((deprecated))
#else
# define DEPRECATED__beagle_msgs__srv__Beagleposition_Request __declspec(deprecated)
#endif

namespace beagle_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct Beagleposition_Request_
{
  using Type = Beagleposition_Request_<ContainerAllocator>;

  explicit Beagleposition_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->user_fir = 0l;
      this->user_sec = 0l;
    }
  }

  explicit Beagleposition_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->user_fir = 0l;
      this->user_sec = 0l;
    }
  }

  // field types and members
  using _user_fir_type =
    int32_t;
  _user_fir_type user_fir;
  using _user_sec_type =
    int32_t;
  _user_sec_type user_sec;

  // setters for named parameter idiom
  Type & set__user_fir(
    const int32_t & _arg)
  {
    this->user_fir = _arg;
    return *this;
  }
  Type & set__user_sec(
    const int32_t & _arg)
  {
    this->user_sec = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__beagle_msgs__srv__Beagleposition_Request
    std::shared_ptr<beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__beagle_msgs__srv__Beagleposition_Request
    std::shared_ptr<beagle_msgs::srv::Beagleposition_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Beagleposition_Request_ & other) const
  {
    if (this->user_fir != other.user_fir) {
      return false;
    }
    if (this->user_sec != other.user_sec) {
      return false;
    }
    return true;
  }
  bool operator!=(const Beagleposition_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Beagleposition_Request_

// alias to use template instance with default allocator
using Beagleposition_Request =
  beagle_msgs::srv::Beagleposition_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace beagle_msgs


#ifndef _WIN32
# define DEPRECATED__beagle_msgs__srv__Beagleposition_Response __attribute__((deprecated))
#else
# define DEPRECATED__beagle_msgs__srv__Beagleposition_Response __declspec(deprecated)
#endif

namespace beagle_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct Beagleposition_Response_
{
  using Type = Beagleposition_Response_<ContainerAllocator>;

  explicit Beagleposition_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->beagle_fir_position = 0l;
      this->beagle_sec_position = 0l;
    }
  }

  explicit Beagleposition_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->beagle_fir_position = 0l;
      this->beagle_sec_position = 0l;
    }
  }

  // field types and members
  using _beagle_fir_position_type =
    int32_t;
  _beagle_fir_position_type beagle_fir_position;
  using _beagle_sec_position_type =
    int32_t;
  _beagle_sec_position_type beagle_sec_position;

  // setters for named parameter idiom
  Type & set__beagle_fir_position(
    const int32_t & _arg)
  {
    this->beagle_fir_position = _arg;
    return *this;
  }
  Type & set__beagle_sec_position(
    const int32_t & _arg)
  {
    this->beagle_sec_position = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__beagle_msgs__srv__Beagleposition_Response
    std::shared_ptr<beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__beagle_msgs__srv__Beagleposition_Response
    std::shared_ptr<beagle_msgs::srv::Beagleposition_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Beagleposition_Response_ & other) const
  {
    if (this->beagle_fir_position != other.beagle_fir_position) {
      return false;
    }
    if (this->beagle_sec_position != other.beagle_sec_position) {
      return false;
    }
    return true;
  }
  bool operator!=(const Beagleposition_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Beagleposition_Response_

// alias to use template instance with default allocator
using Beagleposition_Response =
  beagle_msgs::srv::Beagleposition_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace beagle_msgs

namespace beagle_msgs
{

namespace srv
{

struct Beagleposition
{
  using Request = beagle_msgs::srv::Beagleposition_Request;
  using Response = beagle_msgs::srv::Beagleposition_Response;
};

}  // namespace srv

}  // namespace beagle_msgs

#endif  // BEAGLE_MSGS__SRV__DETAIL__BEAGLEPOSITION__STRUCT_HPP_
