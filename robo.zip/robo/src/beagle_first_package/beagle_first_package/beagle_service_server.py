from beagle_msgs.srv import Beagleposition
import rclpy as rp
from rclpy.node import Node


class beaglePosition(Node):

    def __init__(self) :

        super().__init__('check_user_interface')
        self.server =self.create_service(

            Beagleposition,
            'check_beagle_position',
            self.callback_service

        )

    def callback_service(self, request, response) :
        print("Request : ", request )
        response.user_first = 0
        response.user_sec   = 1
        return response

def main(args = None) :

    rp.init(args = args)
    beagle_position = beaglePosition()
    rp.spin(beagle_position)

    rp.shutdown()

if __name__ == '__main__' :

    main()



